#!/usr/bin/env python
# coding: utf-8

# In[7]:


import math
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split 
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score,r2_score,mean_absolute_error,mean_squared_error
from sklearn.tree import DecisionTreeClassifier
eps = np.finfo(float).eps
from sklearn import linear_model
from numpy import mean
from numpy import cov
from numpy import mean
from numpy import std
from numpy.linalg import eig
import pandas as pd


# In[8]:


df=pd.read_csv('data.csv')


# In[9]:


msk = np.random.rand(len(df)) < 0.8
train = df[msk]
test = df[~msk]


# In[10]:


train_X=train.drop('xAttack',axis=1)
# train_X=(train_X-train_X.mean())/train_X.std()
M = mean(train_X, axis=0)
S = std(train_X,axis=0)
# print(M)
train_X=(train_X - M)/S
# train_X


# In[11]:


mean_vec = np.mean(train_X, axis=0)
cov_mat = (train_X - mean_vec).T.dot((train_X - mean_vec)) / (train_X.shape[0]-1)


# In[12]:


eig_vals, eig_vecs = np.linalg.eig(cov_mat)


# In[13]:


# Make a list of (eigenvalue, eigenvector) tuples
eig_pairs = [(np.abs(eig_vals[i]), eig_vecs[:,i]) for i in range(len(eig_vals))]

# Sort the (eigenvalue, eigenvector) tuples from high to low
eig_pairs.sort()
eig_pairs.reverse()

# # Visually confirm that the list is correctly sorted by decreasing eigenvalues
# print('Eigenvalues in descending order:')
# for i in eig_pairs:
#     print(i[0])


# In[14]:


tot = sum(eig_vals)
var_exp = [(i / tot)*100 for i in sorted(eig_vals, reverse=True)]
cum_var_exp = np.cumsum(var_exp)


# In[15]:


plt.ylabel('% Variance Explained')
plt.xlabel('# of Features')
plt.title('PCA Analysis')
plt.ylim(30,100.5)
plt.style.context('seaborn-whitegrid')
plt.plot(cum_var_exp)


# In[16]:


matrix_w=np.hstack((eig_pairs[0][1].reshape(29,1),eig_pairs[1][1].reshape(29,1),eig_pairs[2][1].reshape(29,1),
                    eig_pairs[3][1].reshape(29,1),eig_pairs[4][1].reshape(29,1),
                    eig_pairs[5][1].reshape(29,1),eig_pairs[6][1].reshape(29,1),
                    eig_pairs[7][1].reshape(29,1),eig_pairs[8][1].reshape(29,1),
                    eig_pairs[9][1].reshape(29,1),eig_pairs[10][1].reshape(29,1),
                    eig_pairs[11][1].reshape(29,1),eig_pairs[12][1].reshape(29,1),eig_pairs[13][1].reshape(29,1)))
Y = train_X.dot(matrix_w)
Y

