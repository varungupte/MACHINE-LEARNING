#!/usr/bin/env python
# coding: utf-8

# In[74]:


import math
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split 
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score,r2_score,mean_absolute_error,mean_squared_error
from sklearn.tree import DecisionTreeClassifier
eps = np.finfo(float).eps
from sklearn import linear_model
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


# In[75]:


#Assigning column names to data
df=pd.read_csv('data.csv',delimiter=";")
alpha = 0.01
iterations = 1000


# In[76]:


msk = np.random.rand(len(df)) < 0.8
train = df[msk]
test = df[~msk]
Y_train=train['quality']
print Y_train.unique()
Y_test=test['quality']
X_train= train.drop(['quality'],axis=1)
X_test= test.drop(['quality'],axis=1)


# In[77]:


X_train = (X_train - X_train.mean())/X_train.std()
X_test = (X_test - X_test.mean())/X_test.std()


# In[78]:


lr = LogisticRegression(solver='lbfgs',multi_class='multinomial',max_iter=iterations)
lr.fit(X_train, Y_train) 
y_pred = lr.predict(X_test)
score = lr.score(X_test,Y_test)
print(score)
print((Y_test == y_pred).mean())
print(accuracy_score(Y_test, y_pred))


# In[79]:


X_train = pd.concat([X_train,Y_train],axis=1)
ones = np.ones([X_train.shape[0],1])
Y_train = X_train.iloc[:,11:12].values
X_train = X_train.iloc[:,0:11]
X_train = np.concatenate((ones,X_train),axis=1)


# In[80]:


theta = np.zeros([9,12])


# In[81]:


def G(x):
    p=1+(np.exp(-x))
    return 1/p


# In[82]:


def gradient_decent(X_train,Y_train,theta1,learning_rate,iterations):
    for i in range(iterations):
        h = G(np.dot(X_train,theta1.T))
        theta1 = theta1 - (learning_rate/len(X_train)) * np.sum(X_train * (h - Y_train), axis=0)
    return theta1


# In[83]:


for i in range(0,9):
    theta1 = np.zeros([1,12])
    W = np.array(Y_train)
    for j in range(len(W)):
        if W[j] == i:
            W[j] = 1
        else:
            W[j] = 0
    theta[i]=gradient_decent(X_train,W,theta1,alpha,iterations)


# In[84]:


y_pred = []
for index,rows in X_test.iterrows():
    rows = list(rows)
    max_h=0
    for a in range(0,9):
        y = 0
        for i in range(len(rows)):
            y = y + rows[i]*theta[a][i+1]
        y = y + theta[a][0]
        y = G(y)
        if y >= max_h:
            label = a
            max_h = y
    y_pred.append(label)


# In[85]:


print((y_pred == Y_test).mean())
print(accuracy_score(Y_test, y_pred))

