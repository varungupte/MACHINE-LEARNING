#!/usr/bin/env python
# coding: utf-8

# In[46]:


import math
import math
import operator
import sys
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split 
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score,r2_score,mean_absolute_error,mean_squared_error
from sklearn.tree import DecisionTreeClassifier
eps = np.finfo(float).eps
from sklearn import linear_model


# In[47]:


#Assigning column names to data
df=pd.read_csv('data.csv')
df=df.drop('Serial No.',axis=1)
columns=df.columns
len(df)
for i in range(len(df)):
    if df.iloc[i,-1] >= 0.5:
        df.iloc[i,-1]=1
    else:
        df.iloc[i,-1]=0


# In[48]:


msk = np.random.rand(len(df)) < 0.8
train = df[msk]
test = df[~msk]
train_k=train
test_k=test
test_k


# In[49]:


# train_X=train[:,:-1]
train_X=train.drop('Chance of Admit ',axis=1)
train_X=(train_X-train_X.mean())/train_X.std()
train_X.insert(0, 'x0', np.ones(len(train)))
train_Y=train['Chance of Admit ']
TX=train_X
TY=train_Y
m=train_X.shape[0]
train_Y=train_Y.values.reshape(m,1)
train_X=train_X.values


# In[50]:


theta = np.zeros([8,1])
alpha = 0.01
iters = 1000


# In[51]:


def computeCost(X,y,theta):
    h = np.dot(X ,theta)
    error = h-y
    loss = np.power(error,2)
    J = np.sum(loss)/(2*m)
    return J


# In[52]:


def G(x):
    p=1+(np.exp(-x))
    return 1/p


# In[53]:


def gradient_descent(X, y, theta, alpha, num_iters):
    costs = np.zeros(num_iters)
    for i in range(0,num_iters):
        gradient = G(np.matmul(X, theta))- y   
        theta = theta - (alpha/len(X))*np.sum(np.matmul(gradient.T,X))
        costs[i] = computeCost(X, y, theta)
    return theta
g = gradient_descent(train_X, train_Y, theta, alpha, iters)
#Print the results...
theta=g


# In[54]:


def predict(theta,test_X):
    test_X.insert(0, 'x0', np.ones(len(test_X)))
    test_X=(test_X-train_X.mean())/test_X.std()
    pred=[]
    for row in range(len(test_X)):
        ans=0
#         print test_X.iloc[row,0],theta[0]
        for i in range(len(test_X.columns)):
            ans+=theta[i]*test_X.iloc[row,i]
        if ans >= 0.5 :
            pred.append(1)
        else:
            pred.append(0)
    return pred


# In[55]:


theta=g


# In[56]:


test_X=test.drop('Chance of Admit ',axis=1)
pred=predict(theta,test_X)
test_Y=test['Chance of Admit ']


# In[57]:


accuracy_score(test_Y,pred)


# In[58]:


# # df=pd.read_csv('data.csv')
# msk = np.random.rand(len(df)) < 0.8
# train = df[msk]
# # test = df[~msk]
# train_X=train.drop('Chance of Admit ',axis=1)
# train_Y=train['Chance of Admit ']
# test_X=test.drop('Chance of Admit ',axis=1)
# test_Y=test['Chance of Admit ']
reg = linear_model.LogisticRegression(solver='lbfgs') 
# train the model using the training sets 
reg.fit(TX,TY)
pred2=reg.predict(test_X)
accuracy_score(test_Y,pred2)


# In[59]:


# finding the euclediandistance 
def euclediandistance(row1,row2,numberofattributes):
    distance=0
    for attribute in range(numberofattributes):
        distance+=pow(row1[attribute]-row2[attribute],2)
    distance=math.sqrt(distance)
    return distance
# euclediandistance([2,2,2,2,2],[1,1,4,4,3],4)


# In[60]:


def findkneighbours(train,testrow,k):
    eucledianlist=[]
    for traininstance in range(len(train)):
        edistance=euclediandistance(train.iloc[traininstance],testrow,len(testrow)-1)
        eucledianlist.append((edistance,train.iloc[traininstance][-1]))
#     neighbourwithdistance=[]
#     neighbourwithdistane=findknearest(euclediandistance,k)
    eucledianlist=sorted(eucledianlist,key=operator.itemgetter(0))
    neighbour=[]
    for row in range(k):
        neighbour.append(eucledianlist[row][1])
    return neighbour


# In[61]:


def predictinstance(neighbour):
    one=0
    zero=1
    for rows in range(len(neighbour)):
        if neighbour[rows] == 1:
            one=one+1
        elif neighbour[rows] == 0:
            zero=zero+1
    if one >= zero :
        return 1
    else :
        return 0


# In[62]:


def predictnew(train,test,k):
    predictlist=[]
    for i in range(len(test)):
        neighbour=findkneighbours(train,test.iloc[i],k)
        predictlist.append(predictinstance(neighbour))
#     print predictlist
    return accuracy_score(test['Chance of Admit '],predictlist)


# In[63]:


def predict(train,test,k):
    predictlist=[]
    for i in range(len(test)):
        neighbour=findkneighbours(train,test.iloc[i],k)
        predictlist.append(predictinstance(neighbour))
#     print predictlist
    print "The below details are for K-NN CLASSIFIER developed:-"
    print "Accuracy score:-"
    print accuracy_score(test['Chance of Admit '],predictlist)
    print "Confusion Matrix:-"
    print confusion_matrix(test['Chance of Admit '],predictlist)
    print "Classification Report:-"
    print classification_report(test['Chance of Admit '],predictlist)
    accuracy=[]
    for i in range(1, 50):
        p=predictnew(train,test,i)
        accuracy.append(p)    
    plt.plot(range(1, 50), accuracy)
    plt.title('Accuracy vs K Value')  
    plt.xlabel('K Value')
    plt.grid(True)
    plt.ylabel('Accuracy')
# print test['Class']    


# In[ ]:


predict(train_k,test_k,5)

