#!/usr/bin/env python
# coding: utf-8

# In[631]:


import math
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split 
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score,r2_score,mean_absolute_error,mean_squared_error
from sklearn.tree import DecisionTreeClassifier
eps = np.finfo(float).eps
from sklearn import linear_model
import copy


# In[632]:


#Assigning column names to data
df=pd.read_csv('data.csv')
df=df.drop('Serial No.',axis=1)
columns=df.columns
len(df)
for i in range(len(df)):
    if df.iloc[i,-1] > 0.5:
        df.iloc[i,-1]=1
    else:
        df.iloc[i,-1]=0


# In[633]:


msk = np.random.rand(len(df)) < 0.8
train = df[msk]
test = df[~msk]


# In[645]:


# train_X=train[:,:-1]
train_X=train.drop('Chance of Admit ',axis=1)
train_X=(train_X-train_X.mean())/train_X.std()
TX=copy.deepcopy(train_X)
train_X.insert(0, 'x0', np.ones(len(train)))
train_Y=train['Chance of Admit ']
TY=copy.deepcopy(train_Y)
m=train_X.shape[0]
train_Y=train_Y.values.reshape(m,1)
train_X=train_X.values


# In[646]:


theta = np.zeros([8,1])
alpha = 0.01
iters = 1000


# In[647]:


def G(x):
    p=1+(np.exp(-x))
    return 1/p


# In[648]:


def gradient_descent(X, y, theta, alpha, num_iters):
    for i in range(0,num_iters):
        gradient = G(np.matmul(X, theta))- y   
        theta = theta - (alpha/len(X))*np.sum(np.matmul(gradient.T,X))
    return theta
g = gradient_descent(train_X, train_Y, theta, alpha, iters)
theta=g


# In[649]:


def predict_new(theta,test_X):
    test_X=(test_X-test_X.mean())/test_X.std()
    test_X.insert(0, 'x0', np.ones(len(test_X)))
    pred=[]
    for row in range(len(test_X)):
        ans=0
        for i in range(len(test_X.columns)):
            ans+=theta[i]*test_X.iloc[row,i]
        ans=G(ans)
        if ans > 0.5 :
            pred.append(1)
        else:
            pred.append(0)
    return pred


# In[650]:


theta=g


# In[651]:


test_X=test.drop('Chance of Admit ',axis=1)
pred=predict_new(theta,test_X)
test_Y=test['Chance of Admit ']


# In[652]:


accuracy_score(test_Y,pred)


# In[656]:


# # df=pd.read_csv('data.csv')
# msk = np.random.rand(len(df)) < 0.8
# train = df[msk]
# # test = df[~msk]
# train_X=train.drop('Chance of Admit ',axis=1)
# train_Y=train['Chance of Admit ']
# test_X=test.drop('Chance of Admit ',axis=1)
# test_Y=test['Chance of Admit ']
reg = linear_model.LogisticRegression(solver='lbfgs') 
# train the model using the training sets 
reg.fit(TX,TY)
test_X=(test_X-test_X.mean())/test_X.std()
pred2=reg.predict(test_X)
accuracy_score(test_Y,pred2)

