#!/usr/bin/env python
# coding: utf-8

# In[2]:


import math
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split 
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score,r2_score,mean_absolute_error,mean_squared_error
from sklearn.tree import DecisionTreeClassifier
eps = np.finfo(float).eps
from sklearn import linear_model
from numpy import mean
from numpy import cov
from numpy import mean
from numpy import std
from numpy.linalg import eig
import pandas as pd
import numpy.random as rd
get_ipython().magic(u'matplotlib inline')
get_ipython().magic(u"config InlineBackend.figure_format = 'retina'")
from sklearn.metrics.cluster import contingency_matrix


# In[3]:


df=pd.read_csv('data.csv')


# In[4]:


msk = np.random.rand(len(df)) < 0.8
train = df[msk]
test = df[~msk]


# In[5]:


train_Y=train['xAttack']
train_X=train.drop('xAttack',axis=1)
# train_X=(train_X-train_X.mean())/train_X.std()
M = mean(train_X, axis=0)
S = std(train_X,axis=0)
# print(M)
train_X=(train_X - M)/S
# train_X


# In[6]:


trainYnew=[]
for i in train_Y:
    if i=='normal':
        trainYnew.append(0)
    elif i=='dos':
        trainYnew.append(1)
    elif i=='r2l':
        trainYnew.append(2)
    elif i=='probe':
        trainYnew.append(3)
    elif i=='u2r':
        trainYnew.append(4)


# In[7]:


mean_vec = np.mean(train_X, axis=0)
cov_mat = (train_X - mean_vec).T.dot((train_X - mean_vec)) / (train_X.shape[0]-1)


# In[8]:


eig_vals, eig_vecs = np.linalg.eig(cov_mat)


# In[9]:


# Make a list of (eigenvalue, eigenvector) tuples
eig_pairs = [(np.abs(eig_vals[i]), eig_vecs[:,i]) for i in range(len(eig_vals))]

# Sort the (eigenvalue, eigenvector) tuples from high to low
eig_pairs.sort()
eig_pairs.reverse()

# # Visually confirm that the list is correctly sorted by decreasing eigenvalues
# print('Eigenvalues in descending order:')
# for i in eig_pairs:
#     print(i[0])


# In[10]:


tot = sum(eig_vals)
var_exp = [(i / tot)*100 for i in sorted(eig_vals, reverse=True)]
cum_var_exp = np.cumsum(var_exp)


# In[11]:


plt.ylabel('% Variance Explained')
plt.xlabel('# of Features')
plt.title('PCA Analysis')
plt.ylim(30,100.5)
plt.style.context('seaborn-whitegrid')
plt.plot(cum_var_exp)


# In[12]:


matrix_w=np.hstack((eig_pairs[0][1].reshape(29,1),eig_pairs[1][1].reshape(29,1),eig_pairs[2][1].reshape(29,1),
                    eig_pairs[3][1].reshape(29,1),eig_pairs[4][1].reshape(29,1),
                    eig_pairs[5][1].reshape(29,1),eig_pairs[6][1].reshape(29,1),
                    eig_pairs[7][1].reshape(29,1),eig_pairs[8][1].reshape(29,1),
                    eig_pairs[9][1].reshape(29,1),eig_pairs[10][1].reshape(29,1),
                    eig_pairs[11][1].reshape(29,1),eig_pairs[12][1].reshape(29,1),eig_pairs[13][1].reshape(29,1)))
Y = train_X.dot(matrix_w)


# In[13]:


print y_actual


# In[ ]:


from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
gmm = GaussianMixture(n_components=5).fit(Y)
labels = gmm.predict(Y)
# plt.scatter(Y[:, 0], Y[:, 1], c=labels, s=40, cmap='viridis');


# In[ ]:


contin=contingency_matrix(labels,trainYnew)
ans=0
for i in contin2:
    ans=ans+max(i)
purity=ans/float(len(train_X))
purity

