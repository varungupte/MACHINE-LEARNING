#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split 
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score
from sklearn.tree import DecisionTreeClassifier
import matplotlib as mpl
import matplotlib.pyplot as plt


# In[4]:


df=pd.read_csv("train.csv")


# In[11]:


X1=df[df['left']==1]
X0=df[df['left']==0]


# In[16]:


fig = plt.figure()
plt.scatter(X1['satisfaction_level'], X1['last_evaluation'],c="yellow",marker='+',label='left=1')
plt.scatter(X0['satisfaction_level'], X0['last_evaluation'],c="green",marker='+',label='left=0')
plt.xlabel('satisfaction_level')
plt.ylabel('number_project')    
plt.title('Matplot scatter plot')
plt.legend(loc=2)
plt.show()

