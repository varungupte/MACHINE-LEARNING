import math
import numpy as np
import sys
import pandas as pd


def preprocess(data):
    count = 0
    pos = 0
    p='5'
    for i in range(len(data)):
        if data[i] == p:
            count = count + 1
            pos = i
    if count != 1 :
        sys.exit("Invalid Path Sequence Given")
    if data[-2] != 'I':
        sys.exit("Invalid Path Sequence Given")
    if data[-1] != '$':
        sys.exit("Invalid Path Sequence Given")
    if data[0] != 'E':
        sys.exit("Invalid Path Sequence Given")
    for i in range(pos):
        if data[i] == 'E':
            pass
        else:
            sys.exit("Please enter valid sequence.")

    pp=len(data)-1
    for i in range(pos+1,pp):
        if data[i] != 'I':
            sys.exit("Please enter valid sequence.")


def handle(num):
    if num == 0:    
        print("probability is 0.")
        sys.exit("log of the probability is undefined.")
    ans=math.log(num)   
    return ans



dna_string="Please enter the DNA sequence:- "
dna = input(dna_string)
path_string="enter the transition sequence:- "
path = input(path_string)

pp2=len(dna)
pp3=len(path)
if pp2+1 != pp3:
   sys.exit("Please enter correct combination of DNA and Path Sequence.")

preprocess(path)

prob={"EA":0.25,"EC":0.25,"EG":0.25,"IG":0.1,"IC":0.1,"IA":0.4}


prob["ET"]=0.25
prob["5A"]=0.05
prob["IT"]=0.4
prob["EE"]=0.9
prob["E5"]=0.1
prob["55"]=0.0
prob["5I"]=1.0
prob["II"]=0.9
prob["I$"]=0.1
prob["5C"]=0.0
prob["5G"]=0.95
prob["5T"]=0.0

for i in range(10):
    p1=prob[path[0]+dna[0]]
    ans = handle(p1)
    break;

for i in range(1,len(path)-1):
    p1=prob[path[i-1]+path[i]]
    h1=handle(p1)
    p2=prob[path[i]+dna[i]]
    h2=handle(p2)
    h3=h1+h2
    ans = ans + h3

p1= prob[path[-2]+path[-1]]
h1=handle(p1)
ans =ans + h1

answer=math.exp(ans)
print("The Probability is:- ",answer)
print("The Log of Probability is:- ",ans)