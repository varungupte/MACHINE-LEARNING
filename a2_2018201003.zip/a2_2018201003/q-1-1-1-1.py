#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import pandas as pd
import numpy as np
import math
import operator
import sys
import matplotlib.pyplot as plt
eps = np.finfo(float).eps
from numpy import log2 as log
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report


# In[2]:


df=pd.read_csv("Robot1", delimiter=r"\s+")
Class=df['class']
df=df.drop(['class','id'],axis=1)
df=df.join(Class)


# In[3]:


# dividing the dataset into train and test
msk=np.random.rand(len(df)) < 0.5
train=df[msk]
test=df[~msk]


# In[4]:


# finding the euclediandistance 
def euclediandistance(row1,row2,numberofattributes):
    distance=0
    for attribute in range(numberofattributes):
        distance+=pow(row1[attribute]-row2[attribute],2)
    distance=math.sqrt(distance)
    return distance
# euclediandistance([2,2,2,2,2],[1,1,4,4,3],4)


# In[5]:


def findkneighbours(train,testrow,k):
    eucledianlist=[]
    for traininstance in range(len(train)):
        edistance=euclediandistance(train.iloc[traininstance],testrow,len(testrow)-1)
        eucledianlist.append((edistance,train.iloc[traininstance][-1]))
#     neighbourwithdistance=[]
#     neighbourwithdistane=findknearest(euclediandistance,k)
    eucledianlist=sorted(eucledianlist,key=operator.itemgetter(0))
    neighbour=[]
    for row in range(k):
        neighbour.append(eucledianlist[row][1])
    return neighbour


# In[6]:


# findkneighbours(train,[2,2,2,2,"Iris-setosa"],5)


# In[7]:


def predictinstance(neighbour):
    one=0
    zero=1
    for rows in range(len(neighbour)):
        if neighbour[rows] == 1:
            one=one+1
        elif neighbour[rows] == 0:
            zero=zero+1
    if one >= zero :
        return 1
    else :
        return 0


# In[8]:


def predictnew(train,test,k):
    predictlist=[]
    for i in range(len(test)):
        neighbour=findkneighbours(train,test.iloc[i],k)
        predictlist.append(predictinstance(neighbour))
#     print predictlist
    return accuracy_score(test['class'],predictlist)


# In[9]:


def predict(train,test,k):
    predictlist=[]
    for i in range(len(test)):
        neighbour=findkneighbours(train,test.iloc[i],k)
        predictlist.append(predictinstance(neighbour))
#     print predictlist
    print "The below details are from model developed:-"
    print "Accuracy score:-"
    print accuracy_score(test['class'],predictlist)
    print "Confusion Matrix:-"
    print confusion_matrix(test['class'],predictlist)
    print "Classification Report:-"
    print classification_report(test['class'],predictlist)
    accuracy=[]
    for i in range(1, 50):
        p=predictnew(train,test,i)
        accuracy.append(p)    
    plt.plot(range(1, 50), accuracy)
    plt.title('Accuracy vs K Value')  
    plt.xlabel('K Value')
    plt.grid(True)
    plt.ylabel('Accuracy')
# print test['Class']    


# In[10]:


predict(train,test,5)


# Reason for better performance:-
# 

# In[11]:


#sklearn inbuilt K Neighbour classifier
from sklearn.neighbors import KNeighborsClassifier
Y_train=train['class']
X_train=train.drop(['class'],axis=1)
model = KNeighborsClassifier(n_neighbors=5)
# Train the model using the training sets
model.fit(X_train,Y_train)

Y_test=test['class']
X_test=test.drop(['class'],axis=1)
#Predict Output
predictlist= model.predict(X_test) # 0:Overcast, 2:Mild
print "The below details are from inbuilt sklearn:-"
print "Accuracy score:-"
print accuracy_score(Y_test,predictlist)
print "Confusion Matrix:-"
print confusion_matrix(Y_test,predictlist)
print "Classification Report:-"
print classification_report(Y_test,predictlist)


# In[12]:


# for testing data against the sample data
filename=sys.argv[1]
df2=pd.read_csv(filename, delimiter=r"\s+")
predict(train,df2,5)

